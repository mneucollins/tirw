-- phpMyAdmin SQL Dump
-- version 2.6.4-pl3
-- http://www.phpmyadmin.net
-- 
-- Host: db178.perfora.net
-- Generation Time: May 04, 2008 at 08:57 AM
-- Server version: 4.0.27
-- PHP Version: 4.3.10-200.schlund.1
-- 
-- Database: `db120899940`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `pitp_comments`
-- 

CREATE TABLE `pitp_comments` (
  `pitp_id` int(11) NOT NULL auto_increment,
  `pitp_comment` text NOT NULL,
  `pitp_timestamp` varchar(14) NOT NULL default '',
  PRIMARY KEY  (`pitp_id`)
) TYPE=MyISAM COMMENT='pitp story junk' AUTO_INCREMENT=33705 ;

-- 
-- Dumping data for table `pitp_comments`
-- 

INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (1, 'blah blah blahb labhh blhab lbh ablh blahb lbha blha blha blh balhb', '1132037329');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (2, 'The hamster turned to the crow, shook the water from his head, and said, \\"Maybe you should try getting out of the toilet on your own next time.\\"', '1132037583');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (3, 'why is this here?', '1132037728');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (4, 'You are reading a dynamic short fiction. You are invited to participate however you\\''d like. Thanks for your time.', '1132066066');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (5, 'some time this week with a compromise plan to reduce the threat', '1132066861');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (6, 'some time this week with a compromise plan to reduce the threat', '1132067531');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (7, 'invited to participate', '1132067817');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (8, 'You are invited to participate however you\\''d like', '1132068465');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (9, 'who dances like a fool', '1132068728');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (10, 'stan\\''s stomach dropped', '1132069352');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (11, 'Both the recent property and patent laws, as well as the latest version of the DMCA, provide clear pathways for us here. Plus, with the new legislation that criminalizes even the attempt or thought of infringing, we can\\''t go wrong.', '1132069618');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (12, 'Have they forgotten their competiton - AWESUMETTES?', '1132074366');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (13, 'FUCK FICTION - NEWS RULEZ!!!', '1132074515');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (14, 'Please yur wuman - buyviagra.com', '1132074763');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (15, 'Please yur wuman - buyviagra.com', '1132075067');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (16, 'what the devil is going on here?', '1132075684');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (17, 'hey whats up', '1132080297');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (18, 'From a cell phone.', '1132082385');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (19, 'rock and roll', '1132084617');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (20, 'I ate chocolate bread', '1132087483');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (21, 'pulsating in rythm', '1132104849');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (22, 'palpitating thrustations', '1132104864');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (23, 'finding the truth at the bottom of a toilet bowl', '1132104881');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (24, 'He wished for life after death, but found only heaven', '1132104929');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (25, 'He wished for life after death, but found only heaven', '1132106153');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (26, 'bush\\''s approval rating lowest it has ever been', '1132111025');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (27, '\\"What are you talking about? How do you think all of the other words got in there? It\\''s coincidence.\\"', '1132111660');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (28, 'Yellow became why is this here?emblematic of the digital prankste', '1132111783');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (29, 'materials protected by the Digital Millenium Copyright Act Version 2', '1132111915');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (30, 'pwned', '1132112372');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (31, 'I have only 40s to offer the gods.', '1132113609');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (32, 'stinking', '1132113676');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (33702, 'hello', '1207791414');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (33703, 'The bubble still exists - what do you call Facebook?', '1207792324');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (34, 'why are you asking me?', '1132113824');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (35, 'porns loves only the blessed midgets', '1132113844');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (36, 'i permeate the pool', '1132113986');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (37, 'my urine stains the waters', '1132113997');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (38, '\\"What the Deuce?\\"', '1132114082');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (39, 'fucking', '1132114168');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (40, 'shit-faced', '1132114173');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (41, 'can you smell the shit? the shit floating in the air?', '1132114215');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (42, 'fucking faggots, they\\''re ruining the news.', '1132114239');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (43, '\\"Have you ever basked on the back of sea turtle?\\"', '1132114355');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (44, 'I need to fix this thing before I do anything else', '1132114417');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (45, 'It makes me feel dirty, Paul.', '1132114479');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (46, 'who wants to add chlorine', '1132114496');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (47, 'Leck mich am Arsch!', '1132114532');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (48, 'I want to go dancing, but where will I find the music...', '1132114641');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (49, 'shitty breeders, they\\''re ruining the news', '1132114696');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (50, 'hi chris are you reading this story?', '1132286818');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (51, 'You are reading a dynamic short fiction. You are invited to participate however you\\''d like.', '1132286881');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (52, 'Yes Shawn, I\\''m reading this, this thing, this creation of excellence.', '1132286883');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (53, 'You need to quit drinking Davis.', '1132286939');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (54, 'This is a test.  This is only a test.', '1132289899');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (55, 'Where in the world...', '1132289924');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (56, 'is Carmen Sandiago?', '1132289942');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (57, 'we\\''re killing him!', '1132300733');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (58, 'We decided we\\''d leave.', '1132323835');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (59, 'It was a really big bummer.', '1132323872');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (60, 'Vamos a celebrar', '1132324215');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (61, 'Valio la pena.', '1132324259');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (62, 'Hola Gringo, can you get me a mobile? Adios, Ariel. Hola, Blockheads. As we made small talk, my daughter came in and said \\"Good afternoon\\" to the folks, and then \\"Hola pap�,\\" to me.  Profesor de ciencias de una escuela de Iowa es nombrado Profesor Nacional del A�o de Wal-Mart. �Hola Arkansas! En Espa�ol.', '1132324613');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (63, 'From CFA, take a left on Millersport, at the second traffic light past\r\nEllicott creek (Y intersection at Wilson Farms) take a left. Byblo\\''s\r\nis in an old house on the left just before the next traffic light (Dodge Rd).', '1132327116');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (64, 'immaculate conceptions', '1132420828');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (65, 'You are reading a dynamic short fiction. You are invited to participate however you\\''d like.', '1132617883');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (67, 'i\\''m tempted to submit something here for this story', '1132696199');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (68, 'vandalize me', '1133289034');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (69, 'You are reading a dynamic short fiction. You are invited to participate however you\\''d like. Thanks for your time. If you\\''re interested in more work like this, please check out the Writing page on my site, shawnrider.com.', '1133289046');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (70, 'an, we\\''re gone. Done. Over. The era of RADDSTURR is in the past.\\" Davis makes quotation marks as he says \\"RADDSTURR\\" and overemphasizes the double-R. \\"What\\''s more, we\\''ve held out so long that we can\\''t even sell out. Our userbase is basically non', '1133289056');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (71, 'wtf?Q?!?!?', '1139494212');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (72, 'But why? And how?', '1139541987');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (73, 'I suppose not... but then again,', '1139542072');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (74, 'aids', '1139846382');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (75, 'penis', '1139846404');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (89, 'i hate reading', '1142975779');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (93, 'published commentary about someone trying to patent a story. This may indeed be becoming possible under the US patent system. Although traditionally artistic works have been denied patents, the US has been moving more and more', '1143817268');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (94, 'storm in a teacup', '1143817295');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (95, 'are you there?', '1143817305');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (96, '\\"^_^\\"', '1143817343');
INSERT INTO `pitp_comments` (`pitp_id`, `pitp_comment`, `pitp_timestamp`) VALUES (33704, 'stop picking on me', '1207792525');
